package com.droidacid.apticalc;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by ShivamD on 5/19/13.
 */
public class aptiSimpleInt extends Activity implements View.OnClickListener{
    String tag = "Simple Interest";
    EditText EtPrincipal, EtRate, EtTime;
    Button calculate;
    TextView TvAnswer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aptisimpleint);
        initialize();

    }

    private void initialize() {

        EtPrincipal = (EditText) findViewById(R.id.EtPrincipal);
        EtRate = (EditText) findViewById(R.id.EtRate);
        EtTime = (EditText) findViewById(R.id.EtTime);
        calculate = (Button) findViewById(R.id.bCalcSimpleInt);
        TvAnswer = (TextView) findViewById(R.id.TvAnswer);

        calculate.setOnClickListener(this);
        Log.d(tag, "in initialize method");
    }

    @Override
    public void onClick(View view) {
        Log.d(tag, "before parsing");
        if(EtPrincipal.getText().toString().equals("")) EtPrincipal.setText("0");
        if(EtRate.getText().toString().equals("")) EtRate.setText("0");
        if(EtTime.getText().toString().equals("")) EtTime.setText("0");
        Double principal = Double.parseDouble(EtPrincipal.getText().toString());
        Double rate = Double.parseDouble(EtRate.getText().toString());
        Double time = Double.parseDouble(EtTime.getText().toString());
        Log.d(tag, "after parsing method");
        String result = "Simple interest is: " + ((principal * rate * time) / 100);
        TvAnswer.setText(result);
        Log.d(tag, "after calculating method");
    }
}
