package com.droidacid.apticalc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class mainMenu extends Activity implements android.view.View.OnClickListener{
	
	Button bapticalc, bformulas, btipsntricks, btesturskills, babout;
	String tag = "Main Menu";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_menu);
		initialize();	
		bapticalc.setOnClickListener(this);
		btesturskills.setOnClickListener(this);
		btipsntricks.setOnClickListener(this);
		bformulas.setOnClickListener(this);
		babout.setOnClickListener(this);
	}
	
	private void initialize(){
		bapticalc = (Button) findViewById(R.id.bapticalc);
		btesturskills = (Button) findViewById(R.id.btesturskills);
		btipsntricks = (Button) findViewById(R.id.btipsntricks);
		bformulas = (Button) findViewById(R.id.bformulas);		
		babout = (Button) findViewById(R.id.babout);
	}

	@Override
	public void onClick(View v) {
		
		switch(v.getId())
		{
		case R.id.bapticalc:
			startActivity(new Intent("com.droidacid.apticalc.APTICALC"));
			Log.d(tag, "Inside aptitude calc switch case");
			break;
		case R.id.btesturskills:
			startActivity(new Intent("com.droidacid.apticalc.TESTURSKILLS"));
			Log.d(tag, "Inside test your skills switch case");
			break;
		case R.id.btipsntricks:
			startActivity(new Intent("com.droidacid.apticalc.TIPSNTRICKS"));
			Log.d(tag, "Inside tips and tricks switch case");
			break;
		case R.id.bformulas:
			startActivity(new Intent("com.droidacid.apticalc.FORMULAS"));
			Log.d(tag, "Inside formulas switch case");
			break;
		case R.id.babout:
			startActivity(new Intent("com.droidacid.apticalc.ABOUT"));
			Log.d(tag, "Inside about switch case");
			break;
		
		}
	}
	
}
