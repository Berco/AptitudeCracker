package com.droidacid.apticalc;

import android.app.Activity;
import android.content.Intent;
//import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class formulas extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.formulas);
		Button bfnumsys = (Button) findViewById(R.id.numsysf);
		
		bfnumsys.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				startActivity(new Intent("com.droidacid.apticalc.BFNUMSYS"));
			}
		});
	}
	
	

}
