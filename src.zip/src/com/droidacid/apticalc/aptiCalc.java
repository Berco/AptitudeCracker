package com.droidacid.apticalc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class aptiCalc extends Activity implements View.OnClickListener {

	String tag = "Aptitude Calculator";
	Button bnumsys , bpercent, btimenwork, btimedist, binterest, blcmhcf, bareavolume;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.apticalc);
		initialize();
    }

    private void initialize() {
        bnumsys = (Button) findViewById(R.id.bnumsys);
        bpercent = (Button) findViewById(R.id.bpercent);
        btimenwork = (Button) findViewById(R.id.btimenwork);
        btimedist = (Button) findViewById(R.id.btimendist);
        binterest = (Button) findViewById(R.id.binterest);
        blcmhcf = (Button) findViewById(R.id.blcmhcf);
        bareavolume = (Button) findViewById(R.id.bareavol);

        bnumsys.setOnClickListener(this);
        bpercent.setOnClickListener(this);
        btimenwork.setOnClickListener(this);
        btimedist.setOnClickListener(this);
        binterest.setOnClickListener(this);
        blcmhcf.setOnClickListener(this);
        bareavolume.setOnClickListener(this);
    }


    @Override
	public void onClick(View button) {
		// Switch case for buttons
		
	switch(button.getId())
	{
	case R.id.bnumsys:
		startActivity(new Intent("com.droidacid.apticalc.APTINUMBERSYS"));
		Log.d(tag, "Inside aptitude number system switch case");
		break;
	case R.id.bpercent:
		startActivity(new Intent("com.droidacid.apticalc.APTIPERCENTAGE"));
		Log.d(tag, "Inside aptitude percentage switch case");
		break;
	case R.id.btimenwork:
		startActivity(new Intent("com.droidacid.apticalc.APTITIMENWORK"));
		Log.d(tag, "Inside aptitude time and work switch case");
		break;
	case R.id.btimendist:
		startActivity(new Intent("com.droidacid.apticalc.APTITIMENDIST"));
		Log.d(tag, "Inside aptitude time and distance switch case");
		break;
    case R.id.binterest:
        startActivity(new Intent("com.droidacid.apticalc.APTIINTEREST"));
        Log.d(tag, "Inside aptitude interest switch case");
        break;
    case R.id.blcmhcf:
        startActivity(new Intent("com.droidacid.apticalc.LCMNHCF"));
        Log.d(tag, "Inside aptitude lcm and hcf switch case");
        break;
    case R.id.bareavol:
        startActivity(new Intent("com.droidacid.apticalc.AREANVOLUME"));
        Log.d(tag, "Inside aptiarea and aptiareavol switch case");
        break;

	}
		
		
	}

}
