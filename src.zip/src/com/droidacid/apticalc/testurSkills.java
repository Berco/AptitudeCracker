package com.droidacid.apticalc;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class testurSkills extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.testurskills);
        initialize();
    }

    private void initialize() {

    }

    @Override
    public void onClick(View view) {
        
    }
}
